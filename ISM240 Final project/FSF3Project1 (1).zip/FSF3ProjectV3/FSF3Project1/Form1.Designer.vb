﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.chkSMM = New System.Windows.Forms.CheckBox()
        Me.chkTreasurer = New System.Windows.Forms.CheckBox()
        Me.chkSec = New System.Windows.Forms.CheckBox()
        Me.chkVice = New System.Windows.Forms.CheckBox()
        Me.chkPresident = New System.Windows.Forms.CheckBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.butClear = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeeklyAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SemesterAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModfiyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblName = New System.Windows.Forms.Label()
        Me.lblEmail = New System.Windows.Forms.Label()
        Me.cboEmail = New System.Windows.Forms.ComboBox()
        Me.MembersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Sf3MembersDataSet = New FSF3Project1.sf3MembersDataSet()
        Me.MembersTableAdapter = New FSF3Project1.sf3MembersDataSetTableAdapters.MembersTableAdapter()
        Me.Sf3MembersDataSet1 = New FSF3Project1.sf3MembersDataSet()
        Me.VisitTableAdapter1 = New FSF3Project1.sf3MembersDataSetTableAdapters.VisitTableAdapter()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.butName = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.MembersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sf3MembersDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sf3MembersDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(18, 257)
        Me.btnAdd.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(110, 44)
        Me.btnAdd.TabIndex = 3
        Me.btnAdd.Text = "Add"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'chkSMM
        '
        Me.chkSMM.AutoSize = True
        Me.chkSMM.Location = New System.Drawing.Point(386, 294)
        Me.chkSMM.Margin = New System.Windows.Forms.Padding(2)
        Me.chkSMM.Name = "chkSMM"
        Me.chkSMM.Size = New System.Drawing.Size(132, 17)
        Me.chkSMM.TabIndex = 9
        Me.chkSMM.Text = "Social Media Manager"
        Me.chkSMM.UseVisualStyleBackColor = True
        '
        'chkTreasurer
        '
        Me.chkTreasurer.AutoSize = True
        Me.chkTreasurer.Location = New System.Drawing.Point(466, 276)
        Me.chkTreasurer.Margin = New System.Windows.Forms.Padding(2)
        Me.chkTreasurer.Name = "chkTreasurer"
        Me.chkTreasurer.Size = New System.Drawing.Size(71, 17)
        Me.chkTreasurer.TabIndex = 8
        Me.chkTreasurer.Text = "Treasurer"
        Me.chkTreasurer.UseVisualStyleBackColor = True
        '
        'chkSec
        '
        Me.chkSec.AutoSize = True
        Me.chkSec.Location = New System.Drawing.Point(386, 276)
        Me.chkSec.Margin = New System.Windows.Forms.Padding(2)
        Me.chkSec.Name = "chkSec"
        Me.chkSec.Size = New System.Drawing.Size(71, 17)
        Me.chkSec.TabIndex = 7
        Me.chkSec.Text = "Secretary"
        Me.chkSec.UseVisualStyleBackColor = True
        '
        'chkVice
        '
        Me.chkVice.AutoSize = True
        Me.chkVice.Location = New System.Drawing.Point(466, 257)
        Me.chkVice.Margin = New System.Windows.Forms.Padding(2)
        Me.chkVice.Name = "chkVice"
        Me.chkVice.Size = New System.Drawing.Size(94, 17)
        Me.chkVice.TabIndex = 6
        Me.chkVice.Text = "Vice President"
        Me.chkVice.UseVisualStyleBackColor = True
        '
        'chkPresident
        '
        Me.chkPresident.AutoSize = True
        Me.chkPresident.Location = New System.Drawing.Point(386, 257)
        Me.chkPresident.Margin = New System.Windows.Forms.Padding(2)
        Me.chkPresident.Name = "chkPresident"
        Me.chkPresident.Size = New System.Drawing.Size(70, 17)
        Me.chkPresident.TabIndex = 5
        Me.chkPresident.Text = "President"
        Me.chkPresident.UseVisualStyleBackColor = True
        '
        'txtName
        '
        Me.txtName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.txtName.Location = New System.Drawing.Point(297, 217)
        Me.txtName.Margin = New System.Windows.Forms.Padding(2)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(212, 30)
        Me.txtName.TabIndex = 2
        '
        'butClear
        '
        Me.butClear.Location = New System.Drawing.Point(131, 257)
        Me.butClear.Margin = New System.Windows.Forms.Padding(2)
        Me.butClear.Name = "butClear"
        Me.butClear.Size = New System.Drawing.Size(101, 44)
        Me.butClear.TabIndex = 4
        Me.butClear.Text = "Clear"
        Me.butClear.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrationToolStripMenuItem, Me.WeeklyAttendanceToolStripMenuItem, Me.SemesterAttendanceToolStripMenuItem, Me.ModfiyToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(566, 24)
        Me.MenuStrip1.TabIndex = 10
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistrationToolStripMenuItem
        '
        Me.RegistrationToolStripMenuItem.Name = "RegistrationToolStripMenuItem"
        Me.RegistrationToolStripMenuItem.Size = New System.Drawing.Size(82, 22)
        Me.RegistrationToolStripMenuItem.Text = "Registration"
        '
        'WeeklyAttendanceToolStripMenuItem
        '
        Me.WeeklyAttendanceToolStripMenuItem.Name = "WeeklyAttendanceToolStripMenuItem"
        Me.WeeklyAttendanceToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.WeeklyAttendanceToolStripMenuItem.Text = "Weekly"
        '
        'SemesterAttendanceToolStripMenuItem
        '
        Me.SemesterAttendanceToolStripMenuItem.Name = "SemesterAttendanceToolStripMenuItem"
        Me.SemesterAttendanceToolStripMenuItem.Size = New System.Drawing.Size(67, 22)
        Me.SemesterAttendanceToolStripMenuItem.Text = "Semester"
        '
        'ModfiyToolStripMenuItem
        '
        Me.ModfiyToolStripMenuItem.Name = "ModfiyToolStripMenuItem"
        Me.ModfiyToolStripMenuItem.Size = New System.Drawing.Size(60, 22)
        Me.ModfiyToolStripMenuItem.Text = "Modfiy "
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblName.Location = New System.Drawing.Point(297, 189)
        Me.lblName.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(64, 25)
        Me.lblName.TabIndex = 20
        Me.lblName.Text = "Name"
        '
        'lblEmail
        '
        Me.lblEmail.AutoSize = True
        Me.lblEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblEmail.Location = New System.Drawing.Point(25, 189)
        Me.lblEmail.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblEmail.Name = "lblEmail"
        Me.lblEmail.Size = New System.Drawing.Size(60, 25)
        Me.lblEmail.TabIndex = 21
        Me.lblEmail.Text = "Email"
        '
        'cboEmail
        '
        Me.cboEmail.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboEmail.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboEmail.DataSource = Me.MembersBindingSource
        Me.cboEmail.DisplayMember = "Email"
        Me.cboEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.cboEmail.FormattingEnabled = True
        Me.cboEmail.Location = New System.Drawing.Point(30, 218)
        Me.cboEmail.Name = "cboEmail"
        Me.cboEmail.Size = New System.Drawing.Size(262, 28)
        Me.cboEmail.TabIndex = 1
        Me.cboEmail.ValueMember = "Name"
        '
        'MembersBindingSource
        '
        Me.MembersBindingSource.DataMember = "Members"
        Me.MembersBindingSource.DataSource = Me.Sf3MembersDataSet
        '
        'Sf3MembersDataSet
        '
        Me.Sf3MembersDataSet.DataSetName = "sf3MembersDataSet"
        Me.Sf3MembersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'MembersTableAdapter
        '
        Me.MembersTableAdapter.ClearBeforeFill = True
        '
        'Sf3MembersDataSet1
        '
        Me.Sf3MembersDataSet1.DataSetName = "sf3MembersDataSet"
        Me.Sf3MembersDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VisitTableAdapter1
        '
        Me.VisitTableAdapter1.ClearBeforeFill = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(208, 26)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(154, 155)
        Me.PictureBox1.TabIndex = 23
        Me.PictureBox1.TabStop = False
        '
        'butName
        '
        Me.butName.Location = New System.Drawing.Point(236, 257)
        Me.butName.Margin = New System.Windows.Forms.Padding(2)
        Me.butName.Name = "butName"
        Me.butName.Size = New System.Drawing.Size(120, 44)
        Me.butName.TabIndex = 24
        Me.butName.Text = "List Name"
        Me.butName.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(566, 327)
        Me.Controls.Add(Me.butName)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cboEmail)
        Me.Controls.Add(Me.lblEmail)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.butClear)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.chkSMM)
        Me.Controls.Add(Me.chkTreasurer)
        Me.Controls.Add(Me.chkSec)
        Me.Controls.Add(Me.chkVice)
        Me.Controls.Add(Me.chkPresident)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.Text = "Registration"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.MembersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sf3MembersDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sf3MembersDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnAdd As Button
    Friend WithEvents chkSMM As CheckBox
    Friend WithEvents chkTreasurer As CheckBox
    Friend WithEvents chkSec As CheckBox
    Friend WithEvents chkVice As CheckBox
    Friend WithEvents chkPresident As CheckBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents butClear As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents RegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WeeklyAttendanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SemesterAttendanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ModfiyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents lblName As Label
    Friend WithEvents lblEmail As Label
    Friend WithEvents Sf3MembersDataSet As sf3MembersDataSet
    Friend WithEvents MembersBindingSource As BindingSource
    Friend WithEvents MembersTableAdapter As sf3MembersDataSetTableAdapters.MembersTableAdapter
    Friend WithEvents Sf3MembersDataSet1 As sf3MembersDataSet
    Friend WithEvents cboEmail As ComboBox
    Friend WithEvents VisitTableAdapter1 As sf3MembersDataSetTableAdapters.VisitTableAdapter
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents butName As Button
End Class
