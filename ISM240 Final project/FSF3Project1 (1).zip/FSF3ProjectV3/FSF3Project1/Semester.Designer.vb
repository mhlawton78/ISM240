﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Semester
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Semester))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeeklyAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SemesterAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModfiyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Sf3MembersDataSet = New FSF3Project1.sf3MembersDataSet()
        Me.Sf3MembersDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ThisSemesterReportBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ThisSemesterReportTableAdapter = New FSF3Project1.sf3MembersDataSetTableAdapters.ThisSemesterReportTableAdapter()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.NameDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EmailDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoleDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Attendence = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sf3MembersDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sf3MembersDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ThisSemesterReportBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrationToolStripMenuItem, Me.WeeklyAttendanceToolStripMenuItem, Me.SemesterAttendanceToolStripMenuItem, Me.ModfiyToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 24)
        Me.MenuStrip1.TabIndex = 21
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistrationToolStripMenuItem
        '
        Me.RegistrationToolStripMenuItem.Name = "RegistrationToolStripMenuItem"
        Me.RegistrationToolStripMenuItem.Size = New System.Drawing.Size(82, 22)
        Me.RegistrationToolStripMenuItem.Text = "Registration"
        '
        'WeeklyAttendanceToolStripMenuItem
        '
        Me.WeeklyAttendanceToolStripMenuItem.Name = "WeeklyAttendanceToolStripMenuItem"
        Me.WeeklyAttendanceToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.WeeklyAttendanceToolStripMenuItem.Text = "Weekly"
        '
        'SemesterAttendanceToolStripMenuItem
        '
        Me.SemesterAttendanceToolStripMenuItem.Name = "SemesterAttendanceToolStripMenuItem"
        Me.SemesterAttendanceToolStripMenuItem.Size = New System.Drawing.Size(67, 22)
        Me.SemesterAttendanceToolStripMenuItem.Text = "Semester"
        '
        'ModfiyToolStripMenuItem
        '
        Me.ModfiyToolStripMenuItem.Name = "ModfiyToolStripMenuItem"
        Me.ModfiyToolStripMenuItem.Size = New System.Drawing.Size(60, 22)
        Me.ModfiyToolStripMenuItem.Text = "Modfiy "
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(324, 384)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(128, 62)
        Me.btnRefresh.TabIndex = 20
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(577, 113)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(154, 155)
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'Sf3MembersDataSet
        '
        Me.Sf3MembersDataSet.DataSetName = "sf3MembersDataSet"
        Me.Sf3MembersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Sf3MembersDataSetBindingSource
        '
        Me.Sf3MembersDataSetBindingSource.DataSource = Me.Sf3MembersDataSet
        Me.Sf3MembersDataSetBindingSource.Position = 0
        '
        'ThisSemesterReportBindingSource
        '
        Me.ThisSemesterReportBindingSource.DataMember = "ThisSemesterReport"
        Me.ThisSemesterReportBindingSource.DataSource = Me.Sf3MembersDataSet
        '
        'ThisSemesterReportTableAdapter
        '
        Me.ThisSemesterReportTableAdapter.ClearBeforeFill = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.NameDataGridViewTextBoxColumn, Me.EmailDataGridViewTextBoxColumn, Me.RoleDataGridViewTextBoxColumn, Me.Attendence})
        Me.DataGridView1.DataSource = Me.ThisSemesterReportBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(13, 41)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(490, 310)
        Me.DataGridView1.TabIndex = 23
        '
        'NameDataGridViewTextBoxColumn
        '
        Me.NameDataGridViewTextBoxColumn.DataPropertyName = "Name"
        Me.NameDataGridViewTextBoxColumn.HeaderText = "Name"
        Me.NameDataGridViewTextBoxColumn.Name = "NameDataGridViewTextBoxColumn"
        Me.NameDataGridViewTextBoxColumn.ReadOnly = True
        '
        'EmailDataGridViewTextBoxColumn
        '
        Me.EmailDataGridViewTextBoxColumn.DataPropertyName = "Email"
        Me.EmailDataGridViewTextBoxColumn.HeaderText = "Email"
        Me.EmailDataGridViewTextBoxColumn.Name = "EmailDataGridViewTextBoxColumn"
        Me.EmailDataGridViewTextBoxColumn.ReadOnly = True
        '
        'RoleDataGridViewTextBoxColumn
        '
        Me.RoleDataGridViewTextBoxColumn.DataPropertyName = "Role"
        Me.RoleDataGridViewTextBoxColumn.HeaderText = "Role"
        Me.RoleDataGridViewTextBoxColumn.Name = "RoleDataGridViewTextBoxColumn"
        Me.RoleDataGridViewTextBoxColumn.ReadOnly = True
        '
        'Attendence
        '
        Me.Attendence.DataPropertyName = "Attendence"
        Me.Attendence.HeaderText = "Attendence"
        Me.Attendence.Name = "Attendence"
        Me.Attendence.ReadOnly = True
        '
        'Semester
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.btnRefresh)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Semester"
        Me.Text = "Semester"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sf3MembersDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sf3MembersDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ThisSemesterReportBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents RegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WeeklyAttendanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SemesterAttendanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ModfiyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents btnRefresh As Button
    Friend WithEvents Sf3MembersDataSetBindingSource As BindingSource
    Friend WithEvents Sf3MembersDataSet As sf3MembersDataSet
    Friend WithEvents ThisSemesterReportBindingSource As BindingSource
    Friend WithEvents ThisSemesterReportTableAdapter As sf3MembersDataSetTableAdapters.ThisSemesterReportTableAdapter
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents NameDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents EmailDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RoleDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Attendence As DataGridViewTextBoxColumn
End Class
