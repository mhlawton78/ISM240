﻿Public Class WeeklyReport


    Private Sub WeeklyReport_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Sf3MembersDataSet.ThisWeekReport' table. You can move, or remove it, as needed.
        Me.ThisWeekReportTableAdapter.Fill(Me.Sf3MembersDataSet.ThisWeekReport)

    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        'TODO: This line of code loads data into the 'Sf3MembersDataSet.ThisWeekReport' table. You can move, or remove it, as needed.
        Me.ThisWeekReportTableAdapter.Fill(Me.Sf3MembersDataSet.ThisWeekReport)
    End Sub

    Private Sub RegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem.Click
        'Open registration form
        Dim mainForm As New Form1
        mainForm.Show()
        Me.Hide()
    End Sub

    Private Sub SemesterAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SemesterAttendanceToolStripMenuItem.Click
        'Open Semester form
        Dim frmSemester As New Semester
        frmSemester.Show()
        Me.Hide()
    End Sub

    Private Sub ModfiyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModfiyToolStripMenuItem.Click
        'Open modify form
        Dim FrmModify As New modify
        FrmModify.Show()
        Me.Hide()
    End Sub

    Private Sub WeeklyReport_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'Closes application and all hidden forms
        Application.Exit()

    End Sub

End Class