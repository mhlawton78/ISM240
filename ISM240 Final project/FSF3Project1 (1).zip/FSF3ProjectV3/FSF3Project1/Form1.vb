﻿Public Class Form1
    'This is our array (List) to store names / roles added this seccion
    Dim list_Name As New List(Of String)
    Dim newVal As String ' This is stored as a value
    Dim found As Boolean = False ' This is for if value is added to database
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'Create strings for values added
        Dim strEmail As String = cboEmail.Text()
        Dim strName As String = txtName.Text()

        If Not (strEmail = "" Or strName = "") Then ' If name and email have valid values
            If (Me.MembersTableAdapter.FillByEmail(Me.Sf3MembersDataSet.Members, strEmail) = 0) Then ' If 0 results
                'Insert new user to members table and a visit to visit table
                Dim intResponce As Integer = MessageBox.Show("Would you like to add new user?", "Register?", MessageBoxButtons.YesNo)
                If (intResponce = DialogResult.Yes) Then
                    Try
                        list_Name.Add(strName) ' changed (moved)
                        Me.MembersTableAdapter.InsertNameRole(strEmail, strName)

                        'Insert new visit to visit table
                        Try
                            Me.VisitTableAdapter1.Insert(strEmail, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
                        Catch ex As Exception
                            MsgBox("There was an error adding the user to Visit table" & ex.ToString)
                        End Try
                    Catch ex As Exception
                        MsgBox("There was an error adding the user to Members table" & ex.ToString)
                    End Try
                End If


            Else
                'Insert new visit to visit table
                Try
                    list_Name.Add(strName)
                    Me.VisitTableAdapter1.Insert(strEmail, DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
                Catch ex As Exception
                    MsgBox("There was an error adding the user to Visit table" & ex.ToString)
                End Try
            End If


        Else
            ' Name and or email are invalid (blank)
            MsgBox("Please enter a value for both name and email")
        End If

        'Reset for next user
        Me.MembersTableAdapter.Fill(Me.Sf3MembersDataSet.Members)
        cboEmail.SelectedIndex = -1
        cboEmail.Text = ""
        txtName.Text = ""
        cboEmail.SelectAll()
    End Sub

    Private Sub butClear_Click(sender As Object, e As EventArgs) Handles butClear.Click

        'Clear all values
        cboEmail.Text = ""
        txtName.Text = ""
        chkPresident.Checked = False
        chkSec.Checked = False
        chkSMM.Checked = False
        chkTreasurer.Checked = False
        chkVice.Checked = False
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Sf3MembersDataSet.Members' table. You can move, or remove it, as needed.
        Me.MembersTableAdapter.Fill(Me.Sf3MembersDataSet.Members)

        'Make default values empty
        cboEmail.Text = ""
        txtName.Text = ""
    End Sub

    Private Sub txtName_Enter(sender As Object, e As EventArgs) Handles txtName.Enter
        If txtName.Text = "" Then ' If name not already inside textbox

            If Not (cboEmail.SelectedIndex() = -1) Then ' If valid index
                txtName.Text = cboEmail.SelectedValue ' Gets name from combo box
                txtName.SelectAll() ' Highligts text in-case user wants to change it (they should also change email or else the new name will not be saved)
            End If
        End If
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'Closes application and all hidden forms
        Application.Exit()

    End Sub

    Private Sub WeeklyAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WeeklyAttendanceToolStripMenuItem.Click
        'Open Weekly Form
        Dim FrmWeeksReport As New WeeklyReport
        FrmWeeksReport.Show()
        Me.Hide()
    End Sub

    Private Sub ModfiyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModfiyToolStripMenuItem.Click
        'Open modify form
        Dim FrmModify As New modify
        FrmModify.Show()
        Me.Hide()

    End Sub

    Private Sub SemesterAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SemesterAttendanceToolStripMenuItem.Click
        'Open Semester form
        Dim frmSemester As New Semester
        frmSemester.Show()
        Me.Hide()

    End Sub

    Private Sub chkPresident_CheckedChanged(sender As Object, e As EventArgs) Handles chkPresident.CheckedChanged
        'Insert visit for president
        If chkPresident.Checked = True Then
            Me.VisitTableAdapter1.Insert("President", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
            list_Name.Add("President")
        End If

    End Sub
    Private Sub chkVice_CheckedChanged(sender As Object, e As EventArgs) Handles chkVice.CheckedChanged
        'Insert visit for vice president
        If chkPresident.Checked = True Then
            Me.VisitTableAdapter1.Insert("Vice President", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
            list_Name.Add("Vice President")
        End If
    End Sub

    Private Sub chkSec_CheckedChanged(sender As Object, e As EventArgs) Handles chkSec.CheckedChanged
        'Insert visit for secretary
        If chkSec.Checked = True Then

            Me.VisitTableAdapter1.Insert("Secretary", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
            list_Name.Add("Secretary")
        End If
    End Sub
    Private Sub chkTreasurer_CheckedChanged(sender As Object, e As EventArgs) Handles chkTreasurer.CheckedChanged
        'Insert visit for treasurer
        If chkTreasurer.Checked = True Then

            Me.VisitTableAdapter1.Insert("Treasurer", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
            list_Name.Add("Treasurer")
        End If
    End Sub
    Private Sub chkSMM_CheckedChanged(sender As Object, e As EventArgs) Handles chkSMM.CheckedChanged
        'Insert visit for social media manager
        If chkSMM.Checked = True Then

            Me.VisitTableAdapter1.Insert("Social Media Manager", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"))
            list_Name.Add("Social Media Manager")
        End If

    End Sub
    Public Sub butName_Click(sender As Object, e As EventArgs) Handles butName.Click
        'Create instance of list name array form
        Dim listNameFrame As New ListNameArray

        'Add items to the list box in form
        For x = 0 To list_Name.Count - 1
            listNameFrame.lisNameBox.Items.Add(list_Name(x).ToString)
        Next

        'Show the form
        listNameFrame.ShowDialog()
    End Sub


End Class
