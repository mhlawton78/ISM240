﻿Public Class Semester
    Private Sub Semester_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Sf3MembersDataSet.ThisSemesterReport' table. You can move, or remove it, as needed.
        Me.ThisSemesterReportTableAdapter.Fill(Me.Sf3MembersDataSet.ThisSemesterReport)

    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        'TODO: This line of code loads data into the 'Sf3MembersDataSet.ThisSemesterReport' table. You can move, or remove it, as needed.
        Me.ThisSemesterReportTableAdapter.Fill(Me.Sf3MembersDataSet.ThisSemesterReport)

    End Sub

    Private Sub RegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem.Click
        'Open registration form
        Dim mainForm As New Form1
        mainForm.Show()
        Me.Hide()
    End Sub

    Private Sub WeeklyAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WeeklyAttendanceToolStripMenuItem.Click
        'Open Weekly Form
        Dim FrmWeeksReport As New WeeklyReport
        FrmWeeksReport.Show()
        Me.Hide()
    End Sub

    Private Sub ModfiyToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ModfiyToolStripMenuItem.Click
        'Open modify form
        Dim FrmModify As New modify
        FrmModify.Show()
        Me.Hide()
    End Sub

    Private Sub Semester_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'Closes application and all hidden forms
        Application.Exit()

    End Sub
End Class