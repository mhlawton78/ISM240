﻿Public Class modify
    Private Sub btnModify_Click(sender As Object, e As EventArgs) Handles btnModify.Click
        'Declare Variables
        Dim strName As String = txtName.Text
        Dim strRole As String = cboRole.Text
        Dim strOriginalEmail As String = cboEmail.Text

        Try
            Me.MembersTableAdapter.UpdateQuery(strName, strRole, strOriginalEmail)
            MsgBox(strName & " was succesfully updated")
            txtName.Text = ""
            cboRole.Text = ""
            cboEmail.Text = ""
            txtName.SelectAll()
        Catch ex As Exception
            MsgBox("There was an error updating the user to Members table" & ex.ToString)
        End Try
    End Sub

    Private Sub modify_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Sf3MembersDataSet.Members' table. You can move, or remove it, as needed.
        Me.MembersTableAdapter.Fill(Me.Sf3MembersDataSet.Members)
    End Sub

    Private Sub RegistrationToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RegistrationToolStripMenuItem.Click
        'Open registration form
        Dim mainForm As New Form1
        mainForm.Show()
        Me.Hide()
    End Sub

    Private Sub WeeklyAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles WeeklyAttendanceToolStripMenuItem.Click
        'Open Weekly Form
        Dim FrmWeeksReport As New WeeklyReport
        FrmWeeksReport.Show()
        Me.Hide()
    End Sub



    Private Sub SemesterAttendanceToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SemesterAttendanceToolStripMenuItem.Click
        'Open Semester form
        Dim frmSemester As New Semester
        frmSemester.Show()
        Me.Hide()
    End Sub

    Private Sub modify_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        'Closes application and all hidden forms
        Application.Exit()

    End Sub
End Class