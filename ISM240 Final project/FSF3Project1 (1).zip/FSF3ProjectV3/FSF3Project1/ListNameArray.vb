﻿Public Class ListNameArray
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'Closes the form and takes them back to registration form
        Me.Close()
    End Sub
End Class