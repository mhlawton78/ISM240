﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class modify
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(modify))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.cboEmail = New System.Windows.Forms.ComboBox()
        Me.MembersBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Sf3MembersDataSet = New FSF3Project1.sf3MembersDataSet()
        Me.cboRole = New System.Windows.Forms.ComboBox()
        Me.btnModify = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WeeklyAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SemesterAttendanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ModfiyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MembersTableAdapter = New FSF3Project1.sf3MembersDataSetTableAdapters.MembersTableAdapter()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MembersBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Sf3MembersDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.FSF3Project1.My.Resources.Resources.project
        Me.PictureBox1.Location = New System.Drawing.Point(374, 78)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(150, 150)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 29
        Me.PictureBox1.TabStop = False
        '
        'cboEmail
        '
        Me.cboEmail.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cboEmail.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cboEmail.DataSource = Me.MembersBindingSource
        Me.cboEmail.DisplayMember = "Email"
        Me.cboEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.cboEmail.FormattingEnabled = True
        Me.cboEmail.Location = New System.Drawing.Point(91, 103)
        Me.cboEmail.Name = "cboEmail"
        Me.cboEmail.Size = New System.Drawing.Size(225, 28)
        Me.cboEmail.TabIndex = 28
        Me.cboEmail.ValueMember = "Name"
        '
        'MembersBindingSource
        '
        Me.MembersBindingSource.DataMember = "Members"
        Me.MembersBindingSource.DataSource = Me.Sf3MembersDataSet
        '
        'Sf3MembersDataSet
        '
        Me.Sf3MembersDataSet.DataSetName = "sf3MembersDataSet"
        Me.Sf3MembersDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'cboRole
        '
        Me.cboRole.FormattingEnabled = True
        Me.cboRole.Items.AddRange(New Object() {"Full Member", "Partial Member", "Guest", "President", "Vice President", "Secretary", "Treasuer", "Social Media Manager"})
        Me.cboRole.Location = New System.Drawing.Point(91, 160)
        Me.cboRole.Name = "cboRole"
        Me.cboRole.Size = New System.Drawing.Size(225, 21)
        Me.cboRole.TabIndex = 27
        '
        'btnModify
        '
        Me.btnModify.Location = New System.Drawing.Point(203, 260)
        Me.btnModify.Name = "btnModify"
        Me.btnModify.Size = New System.Drawing.Size(113, 40)
        Me.btnModify.TabIndex = 26
        Me.btnModify.Text = "Modify User"
        Me.btnModify.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(16, 160)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(32, 13)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "Role:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(16, 111)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "Email:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 23
        Me.Label1.Text = "Name:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(91, 55)
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(225, 20)
        Me.txtName.TabIndex = 22
        '
        'MenuStrip1
        '
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(32, 32)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrationToolStripMenuItem, Me.WeeklyAttendanceToolStripMenuItem, Me.SemesterAttendanceToolStripMenuItem, Me.ModfiyToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(3, 1, 0, 1)
        Me.MenuStrip1.Size = New System.Drawing.Size(559, 24)
        Me.MenuStrip1.TabIndex = 30
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistrationToolStripMenuItem
        '
        Me.RegistrationToolStripMenuItem.Name = "RegistrationToolStripMenuItem"
        Me.RegistrationToolStripMenuItem.Size = New System.Drawing.Size(82, 22)
        Me.RegistrationToolStripMenuItem.Text = "Registration"
        '
        'WeeklyAttendanceToolStripMenuItem
        '
        Me.WeeklyAttendanceToolStripMenuItem.Name = "WeeklyAttendanceToolStripMenuItem"
        Me.WeeklyAttendanceToolStripMenuItem.Size = New System.Drawing.Size(57, 22)
        Me.WeeklyAttendanceToolStripMenuItem.Text = "Weekly"
        '
        'SemesterAttendanceToolStripMenuItem
        '
        Me.SemesterAttendanceToolStripMenuItem.Name = "SemesterAttendanceToolStripMenuItem"
        Me.SemesterAttendanceToolStripMenuItem.Size = New System.Drawing.Size(67, 22)
        Me.SemesterAttendanceToolStripMenuItem.Text = "Semester"
        '
        'ModfiyToolStripMenuItem
        '
        Me.ModfiyToolStripMenuItem.Name = "ModfiyToolStripMenuItem"
        Me.ModfiyToolStripMenuItem.Size = New System.Drawing.Size(60, 22)
        Me.ModfiyToolStripMenuItem.Text = "Modfiy "
        '
        'MembersTableAdapter
        '
        Me.MembersTableAdapter.ClearBeforeFill = True
        '
        'modify
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(559, 313)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.cboEmail)
        Me.Controls.Add(Me.cboRole)
        Me.Controls.Add(Me.btnModify)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtName)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "modify"
        Me.Text = "modify"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MembersBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Sf3MembersDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents cboEmail As ComboBox
    Friend WithEvents cboRole As ComboBox
    Friend WithEvents btnModify As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents RegistrationToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents WeeklyAttendanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents SemesterAttendanceToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ModfiyToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents MembersBindingSource As BindingSource
    Friend WithEvents Sf3MembersDataSet As sf3MembersDataSet
    Friend WithEvents MembersTableAdapter As sf3MembersDataSetTableAdapters.MembersTableAdapter
End Class
